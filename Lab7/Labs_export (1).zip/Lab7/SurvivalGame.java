package labs.lab7;

import java.awt.Point;

public class SurvivalGame {

	// ADD YOUR INSTANCE VARIABLES HERE

	/**
	 * Constructs a new survival game with player
	 */
	public SurvivalGame() {
		// FILL IN
	}


	public Player getPlayer() {
		return new Player(); // FIX ME
	}


	/**
	 * Drops food into the game
	 * 
	 * @param location    food drop location
	 * @param description description of food item
	 * @param energyValue energy value of food item
	 */
	public void dropFood(Point location, String description, int energyValue) {
		// FILL IN
	}

}