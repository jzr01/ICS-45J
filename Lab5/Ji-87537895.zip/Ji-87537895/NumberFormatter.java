package labs.lab5;

/**
 * Formats an integer and returns it as a string
 *
 */

public interface NumberFormatter {

	/**
	 * Formats an integer and returns it as a string
	 * 
	 * @param n the number to format
	 * @return the formattted number
	 */
	String format(int n);

}
