package labs.lab3;

import java.time.LocalDate;

/**
 * Represents a credit card
 *
 */
public class CreditCard {

	long number;
	LocalDate expDate;

	
	/**
	 * Constructs a credit card object with the given number and expiration
	 * date
	 * 
	 * Assume the number passed in will always have 16 digits and will not
	 * start with 0. 
	 * 
	 * Assume the date passed in will always be a valid date.
	 * 
	 * @param number	the credit card number
	 * @param expDate	the credit card expiration date
	 */
	public CreditCard(long number, LocalDate expDate) {
		this.number = number;
		this.expDate = expDate;
	}


	/**
	 * Returns the credit card number
	 * 
	 * @return	the credit card number
	 */
	public long getNumber() {
		return number;
	}


	/**
	 * Returns the credit card expiration date
	 * 
	 * @return	the credit card expiration date
	 */
	public LocalDate getExpirationDate() {
		return expDate;
	}
	
	
	/**
	 * Returns a string containing the card number, with a space inserted
	 * between every 4 digits
	 * 
	 * @return	the card number, with a space inserted between every 4 digits
	 */
	public String getNumberWithSpaces() {
		String s = String.valueOf(number);
		return s.substring(0,4) + " " + s.substring(4,8) + " " + s.substring(8,12) + " " + s.substring(12);
	}


	/**
	 * Returns true if both the card number and expiration date are valid,
	 * false otherwise
	 * 
	 * @return	whether card is valid
	 */
	public boolean isValid() {
		int sum = 0;
		String s = String.valueOf(number);
		for (int i = 0; i < s.length(); i++)
		{
			sum = sum + Character.getNumericValue(s.charAt(i));
		}
		
		int count = 0;
		for (int i = 1; i < s.length(); i = i+2)
		{
			sum = sum + Character.getNumericValue(s.charAt(i));
			if (Character.getNumericValue(s.charAt(i)) > 4)
			{
				count++;
			}
		}
		
		sum = sum + count;
		
		return sum % 3 == 0 && expDate.compareTo(LocalDate.now()) > 0;

	}
}