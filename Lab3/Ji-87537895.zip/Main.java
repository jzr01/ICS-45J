package labs.lab3;

public class Main {

	/**
	 * We'll say that a "quadruplet" in a string is a char appearing four times in a
	 * row. Return the number of quadruplets in the given string. The quadruplets
	 * may overlap.
	 * 
	 * @param str the string to check for quadruplets
	 * @return the number of quadruplets in the string
	 */
	public static int problem1_countQuadruplets(String str) {
		int count  = 0;
		for (int i = 0; i < str.length() - 3; i++)
		{
			char a = str.charAt(i);
			char b = str.charAt(i+1);
			char c = str.charAt(i+2);
			char d = str.charAt(i+3);
			if (a == b && a == c && a == d)
			{
				count++;
			}
 		}
		return count;
	}


	/**
	 * Given a string, return the sum of the digits 0-9 that appear in the string,
	 * ignoring all other characters. Return 0 if there are no digits in the string.
	 * (Note: Character.isDigit(char) tests if a char is one of the chars '0', '1',
	 * .. '9'. Integer.parseInt(String) converts a string to an int.)
	 * 
	 * @param str the string from which to sum the digits
	 * @return the sum of the digits 0-9 that appear in the string
	 */
	public static int problem2_sum(String str) {
		int sum = 0;
		for (int i = 0; i < str.length(); i++)
		{
			char a = str.charAt(i);
			if (Character.isDigit(a))
			{
				sum = sum + Integer.parseInt(String.valueOf(a));
			}
		}
		return sum;
		
	}


	/**
	 * Takes a string as a parameter and returns a string where every appearance of
	 * the lowercase word "are" has been replaced with "are not". The word "are"
	 * should not be immediately preceded or followed by a letter -- so for example
	 * the "are" in "care" or "scared" does not count. (Note:
	 * Character.isLetter(char) tests if a char is a letter.)
	 * 
	 * @param str the string to replaces "are"s in
	 * @return the string with all "are"s replaced with "are not"s.
	 */
	public static String problem3_replace(String str) {
		if (str.length() <= 3)
		{
			if (str.equals("Are") || str.equals("are"))
			{
				return str + " not";
			}
			else
			{
				return str;
			}
		}else 
		{ 
			String new_str = "";
			int j = 0;
			for (int i = 0; i < str.length()-2;i++)
			{
				if (i == 0) 
				{
					if ((str.charAt(i) == 'a' || str.charAt(i) == 'A') && str.charAt(i+1) == 'r' && str.charAt(i+2) == 'e' && ! Character.isLetter(str.charAt(i+3)))
					{
						new_str = str.substring(0,3) + " not";
						j = 3;
					}
				}else if (i == str.length()-3)
				{
					if (str.charAt(i) == 'a' && str.charAt(i+1) == 'r' && str.charAt(i+2) == 'e' && ! Character.isLetter(str.charAt(i-1)))
					{
						if (j == 0)
						{
							new_str = str + " not";
						}else
						{
							new_str = new_str + str.substring(j) + " not";
							j = str.length();
						}
					}
				}else
				{
					if (str.charAt(i) == 'a' && str.charAt(i+1) == 'r' && str.charAt(i+2) == 'e' && ! Character.isLetter(str.charAt(i+3)) && ! Character.isLetter(str.charAt(i-1)))
					{
					if (j == 0)
					{
						new_str = str.substring(0,i+3) + " not";
						j = i + 3;
			 		}
					else
					{
						new_str = new_str + str.substring(j,i+3) + " not";
						j = i + 3;
					}
					}
				}
				
			}
			new_str = new_str + str.substring(j);
			return new_str;
		}
	}


	/**
	 * Takes in a string and returns a string containing all substrings, sorted by
	 * length (ascending), with a comma and a space separating each one
	 * 
	 * @param str the string from which to make substrings
	 * @return string containing all substrings
	 */
	public static String problem4_getAllSubstrings(String str) {
		String sub = "";
		if (str.equals(""))
		{
			return sub;
		}else
		{
			for (int i = 1; i <= str.length();i++)
			{
				for (int j = 0; j < str.length()-i+1; j++)
				{
					sub = sub + str.substring(j,j+i) +", ";
				}
			}
			return sub.substring(0,sub.length()-2);
		}
	}


	/**
	 * Given a non-empty array, return true if there is a place to split the array
	 * so that the sum of the numbers on one side is equal to the sum of the numbers
	 * on the other side.
	 * 
	 * @param nums the array to split
	 * @return true if there is a place to split the array so that the sum of the
	 *         numbers on one side is equal to the sum of the numbers on the other
	 *         side
	 */
	public static boolean problem6_sumSplitBalance(int[] nums) {
		boolean ans = false;
		if (nums.length == 1)
		{
			return ans;
		}
		else
		{
			for (int i = 1; i <= nums.length-1;i++)
			{
				int sum1 = 0;
				int sum2 = 0;
				for (int j = 0; j < i; j++)
				{
					sum1 = sum1 + nums[j];
				}
				
				for (int m = i; m < nums.length;m++)
				{
					sum2 = sum2 + nums[m];
				}
				
				if (sum1 == sum2)
				{
					ans = true;
					break;
				}
			}	
			
		}
		return ans;
	}


	
	/**
	 * Consider the leftmost and rightmost appearances of some value in an array.
	 * We'll say that the "interval" is the number of elements between the two, inclusive.
	 * A single value has an interval of 1. Return the largest interval found in the
	 * given array.
	 * 
	 * @param nums	the array in which to find the interval
	 * @return		the largest interval in the array
	 */
	public static int problem7_maxInterval(int[] nums) {
		if (nums.length == 0)
		{
			return 0;
		}else
		{
			int result = 1;
			for (int i = 0; i < nums.length-1; i++)
			{
				for (int j = i + 1; j < nums.length; j++)
				{
					if (nums[i] == nums[j] && j - i + 1> result)
					{
						result = j - i + 1;
					}
				}
			}
			return result;
		}
	}
}
