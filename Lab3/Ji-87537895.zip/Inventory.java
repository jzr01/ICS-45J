package labs.lab3;

import java.util.ArrayList;

public class Inventory {
	private ArrayList<Item> collection;
	
	
	/**
	 * Constructs a new Inventory
	 */
	public Inventory() {
		collection = new ArrayList<Item>();
	}
	
	
	/**
	 * If an item with the given item's description does not already exist
	 * in the inventory, adds that item to the inventory. If an item with
	 * the given item's description does exist, updates that item with 
	 * the given item's values.
	 * 
	 * @param item	item to add/update
	 */
	public void addOrUpdateItem(Item item) {
		boolean contain = false;
		for (int i = 0; i < collection.size();i++)
		{
			if (collection.get(i).getDescription().equals(item.getDescription()))
			{
				collection.set(i, item);
				contain = true;
			}
		
		}
		if (! contain)
		{
			collection.add(item);
		}
	}
	
	
	/**
	 * Removes item with the given description, if it exists
	 * 
	 * @param description	description of item to remove
	 */
	public void removeItemWithDescription(String description) {
		for (int i = 0; i < collection.size() ; i++)
		{
			if (collection.get(i).getDescription().equals(description))
			{
				collection.remove(i);
			}
		}
	}
	
	
	/**
	 * Returns a report of items that are under-stocked (items whose
	 * current stock is less than their target stock)
	 * 
	 * @return	a string that reports which items need to be ordered
	 * and how many of each. If no items are under-stocked, report reads
	 * "No items under-stocked".
	 */
	public String getUnderstockReport() {
		String result = "";
		for (int i = 0; i < collection.size(); i++)
		{
			if (collection.get(i).getCurrentStock() < collection.get(i).getTargetStock())
			{
				result = result + "Order " + (-collection.get(i).getCurrentStock() + collection.get(i).getTargetStock())+ 
						" more of " + collection.get(i).getDescription()+" | ";
						
		
			}
		}
		
		if (result.equals(""))
		{
			return "No items under-stocked";
		}else
		{
			return result.substring(0,result.length()-3);
		}
		
	}
	
	
	/**
	 * Returns a report of items that are over-stocked (items whose
	 * current stock is more than their target stock)
	 * 
	 * @return	a string that reports which items are overstocked and
	 * by how much. If no items are over-stocked, report reads
	 * "No items over-stocked".
	 */
	public String getOverstockReport() {
		String result = "";
		for (int i = 0; i < collection.size(); i++)
		{
			if (collection.get(i).getCurrentStock() > collection.get(i).getTargetStock())
			{
				result = result + collection.get(i).getDescription() + " over-stocked by " +  (collection.get(i).getCurrentStock() - collection.get(i).getTargetStock())+ 
						" items | ";
						
		
			}
		}
		
		if (result.equals(""))
		{
			return "No items over-stocked";
		}else
		{
			return result.substring(0,result.length()-3);
		}
	}
}