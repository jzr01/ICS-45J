package labs.lab3;

/**
 * Represents a table of values.
 */
public class Table {

	private int[][] values;

	/**
	 * Constructs a table with given rows and columns.
	 * 
	 * @param rows    the rows in the table (assume always > 0)
	 * @param columns the columns in the table (assume always > 0)
	 */
	public Table(int rows, int columns) {
		values = new int[rows][columns];
	}


	/**
	 * Sets a value in the table.
	 * 
	 * @param i the row of the item to modify (assume always within the bounds of the table)
	 * @param j the column of the item to modify (assume always within the bounds of the table)
	 * @param n the number to use for the new value.
	 */
	public void set(int i, int j, int n) {
		values[i][j] = n;
	}


	/**
	 * Computes and returns the average of the adjacent neighbors of the given
	 * table element in all eight surrounding directions. 
	 * 
	 * If the element is located at the boundary of the table, include only 
	 * the neighbors that are in the table. For example if row and column are 
	 * both 0, there are only three neighbors.
	 * 
	 * If the given element has no neighbors, return 0.
	 * 
	 * If no element with the given row & column exists in this table, return 0.
	 * 
	 * @param row    the row of the element
	 * @param column the column of the element
	 * @return the average of the adjacent elements
	 */
	public double neighborAverage(int row, int column) {
		double count = 0.0;
		double sum = 0.0;
		if ( row < values.length &&  column < values[0].length )
		{
		for (int i = row - 1; i < row+2;i++)
		{
			for (int j = column - 1; j < column + 2; j++)
			{
				try
				{
					if (row != i || column != j)
					{
						sum = sum + values[i][j];
						count++;
					}
				}catch(Exception e)
				{}
			}
		}
		return sum/count;
		}else
		{
			return sum;
		}
		
	}


	/**
	 * Returns the sum of a row or column in elements in the table
	 * 
	 * @param i          	the row or column to sum. Assume it will always 
	 * 						be within the bounds of the table
	 * @param horizontal 	if true, then i represents a row, else a column.
	 * @return the sum of the given row or column.
	 */
	public double sum(int i, boolean horizontal) {
		int sum = 0;
		if (horizontal)
		{
			for (int j = 0; j < values[i].length;j++)
			{
				sum = sum + values[i][j];
			}
		}else
		{
			for (int j = 0; j < values.length; j++)
			{
				sum = sum + values[j][i];
			}
		}
		return sum;
	}
	
}
