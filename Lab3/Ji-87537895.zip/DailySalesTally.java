package labs.lab3;

import java.util.ArrayList;

public class DailySalesTally {

	ArrayList<Purchase> collection;

	public DailySalesTally() {
		collection = new ArrayList<Purchase>();
	}


	/**
	 * Adds a purchase to the tally
	 * 
	 * @param p	the purchase
	 */
	public void addPurchase(Purchase p) {
		collection.add(p);
	}
	
	
	/**
	 * Calculates the total for the day for the client with the given name
	 * 
	 * @param clientName	name of the client for whom to calculate the total
	 * @return				total for the given client
	 */
	public double getTotalForClient(String clientName) {
		Purchase info;
		int count = 0;
		double sum = 0;
		for (int i = 0; i < collection.size(); i++)
		{
			info = collection.get(i);
			if (clientName.equals(info.getClientName()))
			{
				double price = info.getPrice(); 
				if (info.isBoutiquePurchase())
				{
					price = price*0.95;
				}
				
				if (count >= 1)
				{
					price = price*0.9;
				}
				
				count++;
				sum = sum + price;
			}
			
		}
		return sum;
	}


	/**
	 * Calculates the grand total for the day for all purchases
	 * 
	 * @return	the grand total for the day for all purchases
	 */
	public double getGrandTotal() {
		double sum = 0;
		ArrayList<String> name_list = new ArrayList<String>();
		for (int i = 0; i < collection.size();i++)
		{
			Purchase info = collection.get(i);
			if (! name_list.contains(info.getClientName()))
			{
				name_list.add(info.getClientName());
			}
		}
		
		for (int i = 0; i < name_list.size(); i++)
		{
			sum = sum + this.getTotalForClient(name_list.get(i));
		}
		
		return sum;
	}
}